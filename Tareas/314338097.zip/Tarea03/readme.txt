Alex Gerardo Fernandez Aguilar -314338097

Para Ejecutar el Programa solo se nececita ejecutar con python cada archivo ya trae cargado cada funcion